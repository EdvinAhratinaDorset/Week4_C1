﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Week4_C1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Q1, Q2, Q3.a, Q3");
            string ExercicesNumber = Console.ReadLine();
            switch(ExercicesNumber)
            {
                case "Q1":
                    Exercice1();
                    break;
                case "Q2":
                    Exercice2();
                    break;
                case "Q3.a":
                    Exercice3A();
                    break;
                case "Q3":
                    Exercice3();
                    break;
                case "Q4":
                    Exercice4();
                    break;
                case "Q5":
                    Exercice5();
                    break;
                case "Q6":
                    Exercice6();
                    break;
                case "Q7":
                    Exercice7();
                    break;
                case "Q8":
                    Exercice8();
                    break;
                case "Q9":
                    Exercice9();
                    break;
            }

            Console.ReadKey();
        }

        static void Exercice1()
        {
            Console.WriteLine("Enter a string (it will exchange the first with the last letter");
            string s1= Console.ReadLine();
            char sTemp0;
            char sTempEnd;
            string stringMiddle;
            if (s1!=null && s1.Length>1)
            {
                sTemp0 = s1[0];
                sTempEnd = s1[s1.Length-1];
                stringMiddle = s1.Substring(1, s1.Length - 2);
                stringMiddle = sTempEnd + stringMiddle + sTemp0;
                s1 = stringMiddle;
            }
            Console.WriteLine("Your new string is :"+s1);
            
        }
        static void Exercice2()
        {
            Console.WriteLine("Enter a sequence of numbers (for example : 3,4,5,6,7,8,9,0)");
            string sequenceOfNumber = Console.ReadLine();
            Console.WriteLine("Enter the sequence of number that you want to know if there is in the first sequence");
            string sequenceWanted = Console.ReadLine();
            bool sequenceAppear = false;
            bool sequenceAppearTemp = false;
            if(sequenceOfNumber != null && sequenceOfNumber.Length !=0 && sequenceWanted!= null && sequenceWanted.Length!=0)
            {
                sequenceAppearTemp = true;
                for (int i = 0; i < sequenceOfNumber.Length; i++)
                {
                    if(sequenceOfNumber[i]==sequenceWanted[0] && i+sequenceWanted.Length<sequenceOfNumber.Length)
                    {
                        for (int j = 0; j < sequenceWanted.Length; j++)
                        {
                            if(sequenceOfNumber[i+j]!=sequenceWanted[j])
                            {
                                sequenceAppearTemp = false;
                            }
                        }
                        if (sequenceAppearTemp == true) sequenceAppear = true;
                    }
                }
                if (sequenceAppear == true) Console.WriteLine("The Sequence appears");
                else Console.WriteLine("The sequence doesn't appear");
            }

        }
        static void Exercice3A()
        {
            Console.WriteLine("Enter a character that you want to get the ASCII number :\nEnter \"stop\" to stop");
            string character1;
            do
            {
                character1 = Console.ReadLine();
                Console.WriteLine("The ASCI code for " + character1[0] + " is : " + (int)character1[0]);
            }
            while(character1 != "stop");
            Console.Clear();
            Console.WriteLine("Program Ended");
            
        }
        static void Exercice3()
        {
            Console.WriteLine("Enter a array of chars, it will sorted it by descending order (example : abcdefgh -> hgfedcba)\nEnter \"stop\" to stop");
            string arrayOfChars;
            string arrayOfCharsTemp;
            string newArray="";
            byte maxValue=0;
            int index = 0;
            int compteur;
            do
            {
                arrayOfChars = Console.ReadLine();
                arrayOfCharsTemp = arrayOfChars;
                if(arrayOfChars!=null && arrayOfChars.Length!=0 && arrayOfChars!="stop")
                {
                    compteur = arrayOfChars.Length - 1;
                    while(compteur>=0)
                    {
                        maxValue = 0;
                        for (int i = 0; i < arrayOfChars.Length; i++)
                        {
                            if (arrayOfChars[i] > maxValue)
                            {
                                maxValue = (byte)arrayOfChars[i];
                                index = i;
                            }
                        }
                        newArray += arrayOfChars[index];
                        arrayOfChars = arrayOfChars.Substring(0, index) + arrayOfChars.Substring(index + 1, arrayOfChars.Length - index - 1);
                        compteur--;
                    }
                    Console.WriteLine("New array of : " + arrayOfCharsTemp + " => " + newArray);


                }
                newArray = "";

            }
            while (arrayOfChars != "stop");
            Console.Clear();
            Console.WriteLine("Program Ended");
        }
        static void Exercice4()
        {
            Console.WriteLine("Give a string that you want the Compressed String (kkkzaee444 => k3z1a1e243)\nWrite \"stop\" to stop");
            string string1;
            string stringTemp;
            string newString = "";
            int compteur = 0;
            bool differentChar = false;
            do
            {
                string1 = Console.ReadLine();
                stringTemp = string1;
                while (stringTemp != "")
                {
                    compteur = 0;
                    do
                    {
                        if (stringTemp.Length>=2 && compteur <stringTemp.Length-1 && stringTemp[compteur] == stringTemp[compteur + 1])
                        {
                            compteur++;
                        }
                        else differentChar = true;
                    }
                    while (differentChar == false);
                    newString += stringTemp[0] + Convert.ToString(compteur + 1);
                    stringTemp = stringTemp.Substring(compteur + 1, stringTemp.Length - compteur - 1);
                }
                Console.WriteLine("Your string : " + string1 + " becomes : " + newString);
            }
            while(string1 != "stop");
            Console.Clear();
            Console.WriteLine("Program Ended");

        }
        static void Exercice5() 
        {
            List<int> listOfArmstrongNumber = new List<int>();
            int sum = 0;
            for (int i = 0; i < 1000; i++)
            {
                string numberInString = Convert.ToString(i);
                for (int y = 0; y < numberInString.Length; y++)
                {
                    sum += (Convert.ToInt32(numberInString[y])-48)* (Convert.ToInt32(numberInString[y]) - 48)* (Convert.ToInt32(numberInString[y]) - 48);
                }
                if (sum == i) Console.WriteLine(i + " is an Armstrong Number");
                sum = 0;
            }

        }
        static void Exercice6() 
        {
            Console.WriteLine("Enter a Array (for exemple : 3,4,5,6)\nEnter \"stop\" to stop the program");
            string array;
            int[] tab;
            int compteur = 0;
            int max = 0;
            do
            {
                array = Console.ReadLine();
                try
                {
                    tab = new int[array.Length / 2 +1];
                    for (int i = 0; i < array.Length; i+=2)
                    {
                        tab[compteur]= Convert.ToInt32(array[i])-48;
                        compteur++;
                    }
                    compteur = 0;
                    for(int i =0; i<tab.Length; i++)
                    {
                        if (tab[i] > max) max = tab[i];
                    }
                    for (int i = 0; i <= max; i++)
                    {
                        for (int j = 0; j < tab.Length; j++)
                        {
                            if (tab[j] == i) compteur++;
                        }
                        if(compteur !=0) Console.WriteLine(i + " is " + compteur + " times");
                        compteur = 0;
                    }
                    max = 0;
                }
                catch (InvalidCastException e)
                {
                    Console.WriteLine(e);
                }
            }
            while (array != "stop");
            Console.Clear();
            Console.WriteLine("Program Ended");
        }
        static void Exercice7() 
        {
            Console.WriteLine("Enter a number wich you want its Factorial\nEnter \"stop\" to stop");
            string numberinString;
            int number;
            int result = 0;
            do
            {
                numberinString = Console.ReadLine();
                try
                {
                    Int32.TryParse(numberinString, out number);
                    if(number>0)
                    {
                        result = 1;
                        for(int i = 2; i<=number;i++)
                        {
                            result *= i;
                        }
                    }
                    Console.WriteLine($"The factorial of {number} is {result}");
                    result = 0;

                }
                catch { }
            }
            while (numberinString!="stop");
            Console.Clear();
            Console.WriteLine("Program Ended");
        }
        static void Exercice8() 
        {
            Console.WriteLine("Enter a string wich you want to count the number of space\nEnter \"stop\" to stop");
            string s1;
            int compteur = 0;
            do
            {
                s1 = Console.ReadLine();
                for (int i = 0; i < s1.Length; i++)
                {
                    if (s1[i] == ' ') compteur++;
                }
                Console.WriteLine($"There is {compteur} spaces in {s1}");
                compteur = 0;
            }
            while (s1 != "stop");
            Console.Clear();
            Console.WriteLine("Program Ended");
        }
        static void Exercice9() 
        {
             
        }
    }
}
